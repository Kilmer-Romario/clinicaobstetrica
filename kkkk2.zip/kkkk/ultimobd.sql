-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Estado`
--

DROP TABLE IF EXISTS `Estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Estado` (
  `id_Estado` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_Estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Estado`
--

LOCK TABLES `Estado` WRITE;
/*!40000 ALTER TABLE `Estado` DISABLE KEYS */;
INSERT INTO `Estado` VALUES (1,'Vino'),(2,'No vino');
/*!40000 ALTER TABLE `Estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Metodo`
--

DROP TABLE IF EXISTS `Metodo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Metodo` (
  `id_Metodo` int(11) NOT NULL AUTO_INCREMENT,
  `Metodocol` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_Metodo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Metodo`
--

LOCK TABLES `Metodo` WRITE;
/*!40000 ALTER TABLE `Metodo` DISABLE KEYS */;
INSERT INTO `Metodo` VALUES (1,'Patector'),(2,'Nofertil'),(3,'Clinomil');
/*!40000 ALTER TABLE `Metodo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Muestra`
--

DROP TABLE IF EXISTS `Muestra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Muestra` (
  `id_Muestra` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_Muestra`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Muestra`
--

LOCK TABLES `Muestra` WRITE;
/*!40000 ALTER TABLE `Muestra` DISABLE KEYS */;
INSERT INTO `Muestra` VALUES (1,'sangre'),(2,'uña'),(3,'pelo'),(4,'saliva'),(5,'moco');
/*!40000 ALTER TABLE `Muestra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Nombres`
--

DROP TABLE IF EXISTS `Nombres`;
/*!50001 DROP VIEW IF EXISTS `Nombres`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `Nombres` AS SELECT 
 1 AS `id_paciente`,
 1 AS `Nombre`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `NotaSalida`
--

DROP TABLE IF EXISTS `NotaSalida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NotaSalida` (
  `id_salida` int(11) NOT NULL AUTO_INCREMENT,
  `id_atencion` int(11) NOT NULL,
  PRIMARY KEY (`id_salida`),
  KEY `fk_NotaSalida_atencion1_idx` (`id_atencion`),
  CONSTRAINT `fk_NotaSalida_atencion1` FOREIGN KEY (`id_atencion`) REFERENCES `atencion` (`id_atencion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotaSalida`
--

LOCK TABLES `NotaSalida` WRITE;
/*!40000 ALTER TABLE `NotaSalida` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotaSalida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PFamiliar`
--

DROP TABLE IF EXISTS `PFamiliar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PFamiliar` (
  `id_atencion` int(11) NOT NULL,
  `id_Metodo` int(11) NOT NULL,
  `id_Estado` int(11) NOT NULL,
  `fecha_programada` datetime NOT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `fk_PFamiliar_Metodo1_idx` (`id_Metodo`),
  KEY `fk_PFamiliar_Estado1_idx` (`id_Estado`),
  CONSTRAINT `fk_PFamiliar_Estado1` FOREIGN KEY (`id_Estado`) REFERENCES `Estado` (`id_Estado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_PFamiliar_Metodo1` FOREIGN KEY (`id_Metodo`) REFERENCES `Metodo` (`id_Metodo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_PFamiliar_atencion1` FOREIGN KEY (`id_atencion`) REFERENCES `atencion` (`id_atencion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PFamiliar`
--

LOCK TABLES `PFamiliar` WRITE;
/*!40000 ALTER TABLE `PFamiliar` DISABLE KEYS */;
INSERT INTO `PFamiliar` VALUES (42,1,2,'2011-04-08 00:00:00'),(53,1,1,'2013-05-11 00:00:00'),(55,2,2,'2014-01-02 00:00:00'),(56,2,2,'2017-02-02 00:00:00');
/*!40000 ALTER TABLE `PFamiliar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atencion`
--

DROP TABLE IF EXISTS `atencion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atencion` (
  `id_atencion` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_atencion` datetime DEFAULT NULL,
  `hora_atencion` datetime DEFAULT NULL,
  `observaciones` varchar(60) DEFAULT NULL,
  `precio` int(11) DEFAULT NULL,
  `id_tipo` int(10) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `fk_atencion_tipo_atencion1_idx` (`id_tipo`),
  KEY `fk_atencion_paciente1_idx` (`id_paciente`),
  KEY `fk_atencion_usuario1_idx` (`id_usuario`),
  CONSTRAINT `atencion_ibfk_1` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_atencion` (`id_tipo`),
  CONSTRAINT `fk_atencion_paciente1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_atencion_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atencion`
--

LOCK TABLES `atencion` WRITE;
/*!40000 ALTER TABLE `atencion` DISABLE KEYS */;
INSERT INTO `atencion` VALUES (1,'2017-05-22 00:00:00',NULL,NULL,NULL,1,17,3),(2,'2017-05-22 00:00:00',NULL,NULL,NULL,2,17,1),(3,'2017-05-22 00:00:00',NULL,NULL,NULL,2,23,3),(4,'2017-05-22 00:00:00',NULL,NULL,NULL,2,30,1),(5,'2017-05-22 00:00:00',NULL,NULL,NULL,2,28,1),(6,'2017-05-23 00:00:00',NULL,NULL,NULL,2,23,3),(7,'2017-05-23 00:00:00',NULL,'sdjsdjssdjkdssdsdsdsd',47,2,25,1),(8,'2017-05-23 00:00:00',NULL,NULL,NULL,2,31,1),(9,'2017-05-23 00:00:00',NULL,NULL,NULL,2,23,1),(10,'2017-05-23 00:00:00',NULL,'gjhgghj',87,2,21,1),(11,'2017-05-23 00:00:00',NULL,NULL,NULL,1,23,3),(12,'2017-05-23 00:00:00',NULL,'g',12,2,23,3),(13,'2017-05-23 00:00:00',NULL,'hj',56,2,23,1),(14,'2017-05-23 00:00:00',NULL,NULL,NULL,2,17,1),(15,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(16,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,3),(17,'2017-05-23 00:00:00',NULL,NULL,NULL,2,31,1),(18,'2017-05-23 00:00:00',NULL,NULL,NULL,3,23,1),(19,'2017-05-23 00:00:00',NULL,NULL,NULL,3,28,1),(20,'2017-05-23 00:00:00',NULL,'dsaaa',35,2,23,3),(21,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(22,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(23,'2017-05-23 00:00:00',NULL,NULL,NULL,1,23,1),(24,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(25,'2017-05-23 00:00:00',NULL,NULL,NULL,1,22,1),(26,'2017-05-23 00:00:00',NULL,NULL,NULL,1,25,1),(27,'2017-05-23 00:00:00',NULL,NULL,NULL,1,21,1),(28,'2017-05-23 00:00:00',NULL,NULL,NULL,2,31,3),(29,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(30,'2017-05-23 00:00:00',NULL,'jajaajajaj',40,1,22,1),(31,'2017-05-23 00:00:00',NULL,'xdxd',40,1,17,1),(32,'2017-05-23 00:00:00',NULL,'Jj kold ',42,1,21,1),(33,'2017-05-23 00:00:00',NULL,'jIIII ',40,1,20,3),(34,'2017-05-23 00:00:00',NULL,'',50,1,19,1),(35,'2017-05-23 00:00:00',NULL,'JOJOJO FELIZ NAVIDAD',50,1,17,1),(36,'2017-05-23 00:00:00',NULL,NULL,NULL,2,17,1),(37,'2017-05-23 00:00:00',NULL,NULL,NULL,1,23,1),(38,'2017-05-23 00:00:00',NULL,NULL,NULL,1,20,1),(39,'2017-05-23 00:00:00',NULL,'Se va a morir',40,2,17,1),(40,'2017-05-23 00:00:00',NULL,NULL,NULL,1,31,1),(41,'2017-05-23 00:00:00',NULL,'',40,1,32,1),(42,'2017-05-23 00:00:00',NULL,'jajajaj',50,3,17,1),(43,'2017-05-23 00:00:00',NULL,'Va ser pappa',40,2,17,1),(44,'2017-05-23 00:00:00',NULL,NULL,NULL,1,17,1),(45,'2017-05-23 00:00:00',NULL,NULL,NULL,3,17,1),(46,'2017-05-23 00:00:00',NULL,NULL,NULL,3,17,1),(47,'2017-05-23 00:00:00',NULL,NULL,NULL,2,17,1),(48,'2017-05-23 00:00:00',NULL,NULL,NULL,3,17,1),(49,'2017-05-23 00:00:00',NULL,'jajajja',40,1,17,1),(50,'2017-05-23 00:00:00',NULL,NULL,NULL,3,17,1),(51,'2017-05-23 00:00:00',NULL,NULL,NULL,2,32,1),(52,'2017-05-23 00:00:00',NULL,'ddds',40,2,17,1),(53,'2017-05-23 00:00:00',NULL,'ssss',30,3,17,1),(54,'2017-05-23 00:00:00',NULL,NULL,NULL,3,17,1),(55,'2017-05-23 00:00:00',NULL,'sadsa',12,3,17,1),(56,'2017-05-23 00:00:00',NULL,'afs',25,3,17,1),(57,'2017-05-29 00:00:00',NULL,'Tmre',50,1,23,3);
/*!40000 ALTER TABLE `atencion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_salida`
--

DROP TABLE IF EXISTS `detalle_salida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_salida` (
  `id_salida` int(11) NOT NULL,
  `id_insumos` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id_salida`,`id_insumos`),
  KEY `fk_detalle_salida_NotaSalida1_idx` (`id_salida`),
  KEY `fk_detalle_salida_insumos` (`id_insumos`),
  CONSTRAINT `fk_detalle_salida_NotaSalida1` FOREIGN KEY (`id_salida`) REFERENCES `NotaSalida` (`id_salida`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_salida_insumos` FOREIGN KEY (`id_insumos`) REFERENCES `insumos` (`id_insumos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_salida`
--

LOCK TABLES `detalle_salida` WRITE;
/*!40000 ALTER TABLE `detalle_salida` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_salida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumos`
--

DROP TABLE IF EXISTS `insumos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumos` (
  `id_insumos` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_insumos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumos`
--

LOCK TABLES `insumos` WRITE;
/*!40000 ALTER TABLE `insumos` DISABLE KEYS */;
/*!40000 ALTER TABLE `insumos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `laboratorio`
--

DROP TABLE IF EXISTS `laboratorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `laboratorio` (
  `id_lab` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_lab`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `laboratorio`
--

LOCK TABLES `laboratorio` WRITE;
/*!40000 ALTER TABLE `laboratorio` DISABLE KEYS */;
INSERT INTO `laboratorio` VALUES (1,'GEnova'),(2,'San fernando'),(3,'Podesta');
/*!40000 ALTER TABLE `laboratorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otros`
--

DROP TABLE IF EXISTS `otros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otros` (
  `id_atencion` int(11) NOT NULL,
  `descripcion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_atencion`),
  CONSTRAINT `fk_otros_atencion1` FOREIGN KEY (`id_atencion`) REFERENCES `atencion` (`id_atencion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otros`
--

LOCK TABLES `otros` WRITE;
/*!40000 ALTER TABLE `otros` DISABLE KEYS */;
INSERT INTO `otros` VALUES (4,'Inyectables'),(5,'Transfusion'),(6,'telescopia'),(7,'inyeccion'),(10,'ahorcar el ganzo'),(12,'f'),(13,'c'),(20,'hhh'),(39,'Morira'),(43,'Teste de embarazao'),(52,'TEst');
/*!40000 ALTER TABLE `otros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente` (
  `id_paciente` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(120) NOT NULL,
  `celular` int(15) DEFAULT NULL,
  `dni` int(8) DEFAULT NULL,
  `fech_nac` datetime DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `talla` float DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `Estado_civil` varchar(15) DEFAULT NULL,
  `telefono` int(12) DEFAULT NULL,
  PRIMARY KEY (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente`
--

LOCK TABLES `paciente` WRITE;
/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
INSERT INTO `paciente` VALUES (17,'Alex Coillo Chambilla',988787667,97668446,'2001-08-05 00:00:00',877,87.7,'ashjdasd','ascnsamcnmsan','Casado(a)',76778768),(19,'f e f',3,3,'1970-01-01 00:00:00',4,3,'','','Soltero(a)',3),(20,'g h t',4,5,'1970-01-01 00:00:00',7,6,'','','Soltero(a)',5),(21,'gre rg rg',5325,43435235,'1970-01-01 00:00:00',23,353,'','','Viudo(a)',23523),(22,'sisa wdwq qweqw',4142142,32424423,'1970-01-01 00:00:00',42,1.24,'','','Soltero(a)',1241421),(23,'roberto pongo condori',982736251,92838912,'1970-01-01 00:00:00',75,1.65,'kasciysa:sds_sdjjsa,com','3rwefewef','Soltero(a)',827328),(24,'roberto pongo condori',3523532,92838912,'1970-01-01 00:00:00',43,54,'ewr','efwf','Soltero(a)',3253532),(25,'Giancarlitos joaquin xd',982372817,38238428,'1970-01-01 00:00:00',45,1.63,'erge','gerg','Soltero(a)',837281),(26,'cv vv v',3892772,22122,'1970-03-04 00:00:00',32,222,'sf3f','f3q33f','Viudo(a)',3837873),(27,'vd cx d',2,2221,'1970-01-01 00:00:00',23,3,'','','Soltero(a)',8),(28,'Jhon Kevin Chipana',982625242,81279752,'1970-01-01 00:00:00',67,1.67,'arrova.com','Av. La cultura','Soltero(a)',26716282),(29,'Alex Coillo Chambilla',999999999,97668446,'1997-09-07 00:00:00',78,1.64,'','Dorec','Viudo(a)',9999999),(30,'isaias lopez yuliza',98766543,12345678,'2006-03-14 00:00:00',34,1.45,'hghhj.com','yghjgjhgjh','Viudo(a)',5234568),(31,'perico de los palotes turpo',216721,38329333,'1990-05-06 00:00:00',70,1.7,'nsdmn','sdf','Casado(a)',52812982),(32,'m m m',6,5,'1970-01-01 00:00:00',6,6,'','g','Soltero(a)',6),(33,'Carlos Apaza Contreras',998856412,8888888,'1970-01-01 00:00:00',60,1.7,'','','Soltero(a)',5552214),(34,'hjsa asd sad',234234,32423423,'1970-01-01 00:00:00',32,332,'','','Casado(a)',324),(35,'jajajaj jajajag ffsfa',5433322,56646744,'1973-03-03 00:00:00',56,1.7,'','','Casado(a)',5633354);
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `papanicolao`
--

DROP TABLE IF EXISTS `papanicolao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `papanicolao` (
  `id_atencion` int(11) NOT NULL,
  `id_lab` int(11) NOT NULL,
  `id_Muestra` int(11) NOT NULL,
  `fecha_periodo` datetime DEFAULT NULL,
  `hijos` int(11) DEFAULT NULL,
  `fecha_entrega` datetime DEFAULT NULL,
  `fecha_recepcion` datetime DEFAULT NULL,
  `fecha_envio` datetime DEFAULT NULL,
  PRIMARY KEY (`id_atencion`),
  KEY `fk_papanicolao_laboratorio1_idx` (`id_lab`),
  KEY `fk_papanicolao_Muestra1_idx` (`id_Muestra`),
  CONSTRAINT `fk_papanicolao_Muestra1` FOREIGN KEY (`id_Muestra`) REFERENCES `Muestra` (`id_Muestra`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_papanicolao_atencion1` FOREIGN KEY (`id_atencion`) REFERENCES `atencion` (`id_atencion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_papanicolao_laboratorio1` FOREIGN KEY (`id_lab`) REFERENCES `laboratorio` (`id_lab`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `papanicolao`
--

LOCK TABLES `papanicolao` WRITE;
/*!40000 ALTER TABLE `papanicolao` DISABLE KEYS */;
INSERT INTO `papanicolao` VALUES (29,2,2,'2004-05-13 00:00:00',4,'2004-09-13 00:00:00','2004-05-13 00:00:00','2004-07-13 00:00:00'),(33,1,4,'2005-07-13 00:00:00',2,'2019-05-14 00:00:00','2005-08-13 00:00:00','2004-11-13 00:00:00'),(35,1,4,'2013-01-05 00:00:00',4,'2013-01-08 00:00:00','2013-01-11 00:00:00','2013-01-05 00:00:00'),(41,1,2,'2013-11-04 00:00:00',2,'2013-11-04 00:00:00','2013-11-04 00:00:00','2013-11-04 00:00:00'),(49,3,5,'2013-05-11 00:00:00',2,'2013-05-11 00:00:00','2013-05-11 00:00:00','2013-05-11 00:00:00'),(57,1,2,'2013-11-04 00:00:00',1,'2013-11-04 00:00:00','2013-11-04 00:00:00','2013-11-04 00:00:00');
/*!40000 ALTER TABLE `papanicolao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_atencion`
--

DROP TABLE IF EXISTS `tipo_atencion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_atencion` (
  `id_tipo` int(10) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_atencion`
--

LOCK TABLES `tipo_atencion` WRITE;
/*!40000 ALTER TABLE `tipo_atencion` DISABLE KEYS */;
INSERT INTO `tipo_atencion` VALUES (1,'Papanicolao'),(2,'Otros'),(3,'P. Familiar');
/*!40000 ALTER TABLE `tipo_atencion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `usuar`
--

DROP TABLE IF EXISTS `usuar`;
/*!50001 DROP VIEW IF EXISTS `usuar`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `usuar` AS SELECT 
 1 AS `id_usuario`,
 1 AS `Nusuario`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'joaquin','vecinita'),(3,'joaquina','jorge');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `Nombres`
--

/*!50001 DROP VIEW IF EXISTS `Nombres`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `Nombres` AS select `paciente`.`id_paciente` AS `id_paciente`,`paciente`.`nombres` AS `Nombre` from `paciente` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `usuar`
--

/*!50001 DROP VIEW IF EXISTS `usuar`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `usuar` AS select `usuario`.`id_usuario` AS `id_usuario`,concat(`usuario`.`apellidos`,', ',`usuario`.`nombres`) AS `Nusuario` from `usuario` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-29 14:00:31
