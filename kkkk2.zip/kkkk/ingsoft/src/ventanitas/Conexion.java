package ventanitas;

import java.sql.*;

public class Conexion 
{
    Connection cn;
    Statement st;
   
   public Connection conexion()  
   {
      try
      {
            Class.forName("com.mysql.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
            System.out.println("Se hizo la conexion exitosa");
      }
      catch(ClassNotFoundException | SQLException e)
      {
      System.out.println(e.getMessage());
      }return cn;
             
   }
   Statement createStatement(){
       throw new UnsupportedOperationException("No soportado");
   }
   
}    
            
            

   
