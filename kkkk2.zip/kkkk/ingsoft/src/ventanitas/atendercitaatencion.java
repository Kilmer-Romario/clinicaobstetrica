
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanitas;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import javax.swing.text.JTextComponent;

public class atendercitaatencion extends javax.swing.JFrame {

    
Operaciones operacion= new Operaciones();
    /**
     * Creates new form atendercitaatencion
     */
    public atendercitaatencion() {
        initComponents();
         this.setLocationRelativeTo(null);
         bloquear();
         
         
         boxNombre.getEditor().getEditorComponent().addKeyListener(new KeyAdapter() {

@Override
public void keyReleased(KeyEvent evt)
	{
		String CadenaEscrita=boxNombre.getEditor().getItem().toString();
        
       if(evt.getKeyCode()==KeyEvent.VK_ENTER)
       {
       buscar(CadenaEscrita);
               }
    
        if(evt.getKeyCode()>=65 && evt.getKeyCode()<=90 || evt.getKeyCode()>=96 && evt.getKeyCode()<=105 || evt.getKeyCode()==8 )
	{ 
	boxNombre.setModel(operacion.getLista(CadenaEscrita));
	if(boxNombre.getItemCount()>0)
	  {
		boxNombre.showPopup();
		if(evt.getKeyCode()!=8)
		  {
		   ((JTextComponent)boxNombre.getEditor().getEditorComponent()).select(CadenaEscrita.length(),boxNombre.getEditor().getItem().toString().length());
		  }
		else{
			boxNombre.getEditor().setItem(CadenaEscrita);
		     }
	  }
        else{	boxNombre.addItem(CadenaEscrita);}
	}
	}

});
         
    }
       
    
String Item="";
String id_a="";
int id_u,id_ta;


        void desbloquear(){
       
            jButton5.setEnabled(true);
            boxNombre.setEnabled(true);
            Usuario.setEnabled(true);    
         }

    void bloquear(){
        
       jButton5.setEnabled(false);
      ndni.setEnabled(false);
      boxNombre.setEnabled(false);
      Usuario.setEnabled(false);
               }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jButton2 = new javax.swing.JButton();
        natiposatencion = new javax.swing.JButton();
        nadatosatencion = new javax.swing.JButton();
        boxNombre = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        nacancelar = new javax.swing.JButton();
        ndni = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        natipoatencion = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        Usuario = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        ncod = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("Atención");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 110, 40));

        natiposatencion.setText("Tipos de atención");
        natiposatencion.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(natiposatencion, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 140, 30));

        nadatosatencion.setText("Datos de atención");
        nadatosatencion.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(nadatosatencion, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 150, 30));

        boxNombre.setEditable(true);
        boxNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxNombreActionPerformed(evt);
            }
        });
        getContentPane().add(boxNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 220, -1));

        jButton5.setText("Siguiente");
        jButton5.setBorder(new javax.swing.border.MatteBorder(null));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 420, 140, 40));

        nacancelar.setText("Cancelar");
        nacancelar.setBorder(new javax.swing.border.MatteBorder(null));
        nacancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nacancelarMouseClicked(evt);
            }
        });
        nacancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nacancelarActionPerformed(evt);
            }
        });
        getContentPane().add(nacancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, 140, 40));
        getContentPane().add(ndni, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 220, 140, -1));

        jLabel4.setText("Tipo de atención :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        jLabel8.setText("DNI :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 230, 80, -1));

        natipoatencion.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Papanicolao", "P. Familiar", "Otros" }));
        natipoatencion.setSelectedIndex(-1);
        natipoatencion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        natipoatencion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                natipoatencionActionPerformed(evt);
            }
        });
        getContentPane().add(natipoatencion, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, -1, -1));

        jLabel5.setText("Usuario");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 80, -1));

        jLabel6.setText("Paciente :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 80, -1));

        jPanel1.setBackground(new java.awt.Color(212, 66, 235));

        jLabel3.setFont(new java.awt.Font("Ubuntu", 1, 24)); // NOI18N
        jLabel3.setText("NUEVA ATENCIÓN");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel1.add(jLabel3);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 250, 60));

        Usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 260, 210, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ATENDERCITA.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 490));
        getContentPane().add(ncod, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 220, 50, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/reservarcita1.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void nacancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nacancelarMouseClicked
       panel c=new panel();
       c.setVisible(true);
       dispose();
    }//GEN-LAST:event_nacancelarMouseClicked

    private void nacancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nacancelarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nacancelarActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       Conexion con = new Conexion();
        Connection cn= con.conexion();
        
        Item=natipoatencion.getSelectedItem().toString();
        java.util.Date fecha = new java.util.Date();
        java.sql.Date fechasql = new java.sql.Date(fecha.getTime());
        capturar();
        
        try {
           PreparedStatement pps = cn.prepareStatement("INSERT INTO atencion(id_tipo,id_paciente,id_usuario,fecha_atencion) VALUES(?,?,?,?)");
           pps.setInt(1, id_ta);
           pps.setInt(2, Integer.parseInt(ncod.getText()));
           pps.setInt(3, id_u);
           pps.setDate(4, fechasql);
           pps.executeUpdate();
      } catch (SQLException ex) {
           
           Logger.getLogger(registrodepaciente1.class.getName()).log(Level.SEVERE, null, ex);
           Item="";
                
       }
       
        
        switch(Item) {
            case "Papanicolao":
                atendercitaatenciondatosconsulta d=new atendercitaatenciondatosconsulta();
                d.setVisible(true);
                dispose();
                break;
            case "P. Familiar":
                atendercitaatenciondatoconsulta c=new atendercitaatenciondatoconsulta();
                c.setVisible(true);
                dispose();
                break;
            case "Otros":
                atendercita b=new atendercita();
                b.setVisible(true);
                dispose();
                   break;
            default:
                atendercitaatencion e=new atendercitaatencion();
                e.setVisible(true);
                dispose();
                break;
                
                    }  
       
    }                                        

    private void napacienteActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

                                       

    private void CappacActionPerformed(java.awt.event.ActionEvent evt) {                                       
    /*  System.out.println(id_a);
        
    java.util.Date fecha = new java.util.Date();
    System.out.println(fecha);
        */
    }                                      
void capturar()
{
          
        try {
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
           Statement Sent = con.createStatement();
           ResultSet rs1 = Sent.executeQuery("select * from usuar where Nusuario= '"+this.Usuario.getSelectedItem()+"'");
        rs1.next();
        id_u= rs1.getInt("id_usuario");
       } catch(SQLException e) {
               System.out.println(e.getMessage());
               }
        id_a = (String) natipoatencion.getSelectedItem();
        switch(id_a) {
            case "Papanicolao":
                id_ta=1;
                break;
            case "P. Familiar":
                id_ta=3;
                break;
            case "Otros":
                id_ta=2;
                break;
                           }  
    }//GEN-LAST:event_jButton5ActionPerformed

    private void natipoatencionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_natipoatencionActionPerformed
       desbloquear();

    this.Usuario.removeAllItems();
    try {
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
           Statement Sent = con.createStatement();
           ResultSet rt = Sent.executeQuery("select * from usuar");
        while(rt.next()){
        this.Usuario.addItem(rt.getString("Nusuario"));}

       } catch(SQLException e) {
               System.out.println(e.getMessage());
       }                                 

    }//GEN-LAST:event_natipoatencionActionPerformed


    private void UsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsuarioActionPerformed

    private void boxNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_boxNombreActionPerformed
 public void buscar(String nombre)
   {
      
        String datos[]=operacion.buscar(nombre);
 if(datos[0]!=null){
  ncod.setText(datos[0]);
  ndni.setText(datos[1]);
 
 }else{
	JOptionPane.showMessageDialog(rootPane,"CAgaste","Error",WARNING_MESSAGE);
  }
   }
   

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(atendercitaatencion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(atendercitaatencion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(atendercitaatencion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(atendercitaatencion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new atendercitaatencion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Usuario;
    private javax.swing.JComboBox<String> boxNombre;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton nacancelar;
    private javax.swing.JButton nadatosatencion;
    private javax.swing.JComboBox<String> natipoatencion;
    private javax.swing.JButton natiposatencion;
    private javax.swing.JTextField ncod;
    private javax.swing.JTextField ndni;
    // End of variables declaration//GEN-END:variables
}
