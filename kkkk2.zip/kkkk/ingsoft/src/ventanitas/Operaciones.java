/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanitas;

import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author angel
 */
public class Operaciones {
    
    public DefaultComboBoxModel getLista(String CadenaEscrita){
        int jeje;
            DefaultComboBoxModel modelo = new DefaultComboBoxModel();
       try {
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
           java.sql.Statement Sent = con.createStatement();
           ResultSet rs = Sent.executeQuery("Select id_paciente,nombres from paciente where nombres Like '"+CadenaEscrita+"%';");
        while(rs.next()){
        modelo.addElement(rs.getString("nombres"));}   
        jeje=rs.getInt("id_paciente");
      System.out.println(jeje);
        
       } catch(SQLException e) {
               System.out.println(e.getMessage());
               }
    return modelo;
        }
    

    public String [] buscar(String nombre){
        String[] datos = new String[2];
        
       try {
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
           java.sql.Statement Sent = con.createStatement();
           ResultSet rs = Sent.executeQuery("Select id_paciente,dni from paciente where nombres Like '"+nombre+"%';");
           while(rs.next()){
        
        for(int i=0; i < datos.length; i++)
        {
        datos[i]= rs.getString(i+1);
        }}   

       } catch(SQLException e) {
           return null;

       }
    return datos;
    
    }
    /*
public Operar(String nombre){
    try {
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb", "root","1234");
           java.sql.Statement Sent = con.createStatement();
           ResultSet rs = Sent.executeQuery("Select id_usuario from paciente where nombres Like '"+nombre+"%';");
        atendercitaatencion.cod2=rs.getInt("id_usuario");
           
       } catch(SQLException e) {}

    
    }
    */
    
}