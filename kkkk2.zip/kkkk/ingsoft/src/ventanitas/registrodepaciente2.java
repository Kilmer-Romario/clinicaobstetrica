/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanitas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class registrodepaciente2 extends javax.swing.JFrame {

   Conexion con = new Conexion();
   Connection cn= con.conexion();
 
    
    
    public registrodepaciente2() {
        initComponents();
         this.setLocationRelativeTo(null);
         
    }

   
    void reporte(String valor){
        DefaultTableModel modelo =  new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Dni");
        modelo.addColumn("Fecha de nacimiento");
        modelo.addColumn("Peso");
        modelo.addColumn("Talla");
        modelo.addColumn("Celular");

        rptabla.setModel(modelo);
        String sql="";
        if(valor.equals(""))
        {
            sql="SELECT nombres,dni,date_format(fech_nac,'%d/%m/%y'),peso,talla,celular FROM paciente";
        }
        else{
            sql="SELECT nombres,dni,date_format(fech_nac,'%d/%m/%y'),peso,talla,celular FROM paciente WHERE nombres Like '%"+valor+"%'";
       
        }
        
       String []datos = new String [8];  
       try {
           Statement st = cn.createStatement();
           ResultSet rs = st.executeQuery(sql);
           while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                
                
                modelo.addRow(datos);
           }
           rptabla.setModel(modelo);
       } catch (SQLException ex) {
           Logger.getLogger(registrodepaciente2.class.getName()).log(Level.SEVERE, null, ex);
       }
            
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rpmenu = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jScrollPane1 = new javax.swing.JScrollPane();
        rptabla = new javax.swing.JTable();
        rpbuscar = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        rpmantenimiento = new javax.swing.JButton();
        rpbusqueda = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jMenuItem1.setText("Modificar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        rpmenu.add(jMenuItem1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rptabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        rptabla.setComponentPopupMenu(rpmenu);
        jScrollPane1.setViewportView(rptabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 750, 300));

        rpbuscar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(rpbuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 430, 30));

        jButton2.setBackground(new java.awt.Color(0, 102, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 100, 110, 40));

        jButton1.setBackground(new java.awt.Color(0, 102, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, 110, 40));

        rpmantenimiento.setBackground(new java.awt.Color(0, 102, 102));
        rpmantenimiento.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        rpmantenimiento.setForeground(new java.awt.Color(255, 255, 255));
        rpmantenimiento.setText("Mantenimieto");
        rpmantenimiento.setBorder(new javax.swing.border.MatteBorder(null));
        rpmantenimiento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rpmantenimientoMouseClicked(evt);
            }
        });
        getContentPane().add(rpmantenimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 140, 40));

        rpbusqueda.setBackground(new java.awt.Color(0, 102, 102));
        rpbusqueda.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        rpbusqueda.setForeground(new java.awt.Color(255, 255, 255));
        rpbusqueda.setText("Búsqueda");
        rpbusqueda.setBorder(new javax.swing.border.MatteBorder(null));
        rpbusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpbusquedaActionPerformed(evt);
            }
        });
        getContentPane().add(rpbusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 150, 40));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/registropacientes2_2.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/registropacientes1_2.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rpbusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpbusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rpbusquedaActionPerformed

    private void rpmantenimientoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rpmantenimientoMouseClicked
        registrodepaciente1 n=new  registrodepaciente1();
       n.setVisible(true);
       dispose();
    }//GEN-LAST:event_rpmantenimientoMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    
    reporte(rpbuscar.getText());    
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
      /*registrodepaciente1 d=new registrodepaciente1();
        d.setVisible(true);
       dispose();
       
       int fila = rptabla.getSelectedRow();
       if(fila>=0){
         registrodepaciente1.rpnombre.setText(rptabla.getValueAt(fila, 0).toString());
          registrodepaciente1.rpapellidopaterno.setText(rptabla.getValueAt(fila, 1).toString());
         registrodepaciente1.rpapellidomaterno.setText(rptabla.getValueAt(fila, 2).toString());
        registrodepaciente1.rpdni.setText(rptabla.getValueAt(fila, 3).toString());
       
        
          
       }
       else{
           
           JOptionPane.showMessageDialog(null, "Fila no seleccionada");
       }
    }//GEN-LAST:event_jMenuItem1ActionPerformed
*/}
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        panel b=new panel();
        b.setVisible(true);
        dispose();   
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registrodepaciente2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField rpbuscar;
    private javax.swing.JButton rpbusqueda;
    private javax.swing.JButton rpmantenimiento;
    private javax.swing.JPopupMenu rpmenu;
    private javax.swing.JTable rptabla;
    // End of variables declaration//GEN-END:variables
}
