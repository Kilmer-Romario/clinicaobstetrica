
package ventanitas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class registrodepaciente1 extends javax.swing.JFrame {

   Conexion con = new Conexion();
   Connection cn= con.conexion();
   int band;
 
           public registrodepaciente1() {
        initComponents();
        this.setLocationRelativeTo(null);
        bloquear();
        
    }
          
     
    void bloquear(){
        
      rpnombre.setEnabled(false);
      rpdni.setEnabled(false);
      rppeso.setEnabled(false);
      rptalla.setEnabled(false);
      rpcel.setEnabled(false);
      rptel.setEnabled(false);
      rpemail.setEnabled(false);
      rpdireccion.setEnabled(false);
      rpestcivil.setEnabled(false);
      rpdia.setEnabled(false);
      rpmes.setEnabled(false);
      rpaño.setEnabled(false);
      rpguardar.setEnabled(false);
         
        
                       
    }
    void desbloquear(){
        
      rpnombre.setEnabled(true);
      rpdni.setEnabled(true);
      rppeso.setEnabled(true);
      rptalla.setEnabled(true);
      rpcel.setEnabled(true);
      rptel.setEnabled(true);
      rpemail.setEnabled(true);
      rpdireccion.setEnabled(true);
      rpestcivil.setEnabled(true);
      rpdia.setEnabled(true);
      rpmes.setEnabled(true);
      rpaño.setEnabled(true);
      rpguardar.setEnabled(true);
      rpmodificar.setEnabled(false);  
    
            
    }
    
    void limpiar(){
       rpnombre.setText(null);
      rpdni.setText(null);
      rppeso.setText(null);
      rptalla.setText(null);
      rpcel.setText(null);
      rptel.setText(null);
      rpemail.setText(null);
      rpdireccion.setText(null);
      rpestcivil.setSelectedItem(null);
      rpdia.setSelectedItem(null);
      rpmes.setSelectedItem(null);
      rpaño.setSelectedItem(null);
        
        
    }
              
            
            
            
            
            
            
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rpnombre = new javax.swing.JTextField();
        rpdni = new javax.swing.JTextField();
        rptel = new javax.swing.JTextField();
        rpemail = new javax.swing.JTextField();
        rpdireccion = new javax.swing.JTextField();
        rpestcivil = new javax.swing.JComboBox<>();
        rppeso = new javax.swing.JTextField();
        rptalla = new javax.swing.JTextField();
        rpcel = new javax.swing.JTextField();
        rpnuevo = new javax.swing.JButton();
        rpguardar = new javax.swing.JButton();
        rpmodificar = new javax.swing.JButton();
        rpcancelar = new javax.swing.JButton();
        rpmantenimiento = new javax.swing.JButton();
        rpbusqueda = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        rpdia = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        rpmes = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        rpaño = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rpnombre.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rpnombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rpnombreKeyTyped(evt);
            }
        });
        getContentPane().add(rpnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 210, 20));

        rpdni.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rpdni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rpdniKeyTyped(evt);
            }
        });
        getContentPane().add(rpdni, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 210, 20));

        rptel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rptel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rptelKeyTyped(evt);
            }
        });
        getContentPane().add(rptel, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 220, 20));

        rpemail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rpemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpemailActionPerformed(evt);
            }
        });
        getContentPane().add(rpemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 366, 550, 20));

        rpdireccion.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(rpdireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 400, 550, 20));

        rpestcivil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Soltero(a)", "Casado(a)", "Viudo(a)", "Divorciado(a)" }));
        rpestcivil.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(rpestcivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 200, 170, -1));

        rppeso.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rppeso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rppesoKeyTyped(evt);
            }
        });
        getContentPane().add(rppeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 240, 170, 20));

        rptalla.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(rptalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 270, 170, 20));

        rpcel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        rpcel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                rpcelKeyTyped(evt);
            }
        });
        getContentPane().add(rpcel, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 330, 230, 20));

        rpnuevo.setBackground(new java.awt.Color(0, 102, 153));
        rpnuevo.setFont(new java.awt.Font("Segoe UI Semilight", 1, 14)); // NOI18N
        rpnuevo.setText("Nuevo");
        rpnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpnuevoActionPerformed(evt);
            }
        });
        getContentPane().add(rpnuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 440, 100, -1));

        rpguardar.setBackground(new java.awt.Color(0, 102, 153));
        rpguardar.setFont(new java.awt.Font("Segoe UI Semilight", 1, 14)); // NOI18N
        rpguardar.setText("Guardar");
        rpguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpguardarActionPerformed(evt);
            }
        });
        getContentPane().add(rpguardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 440, 100, -1));

        rpmodificar.setBackground(new java.awt.Color(0, 102, 153));
        rpmodificar.setFont(new java.awt.Font("Segoe UI Semilight", 1, 14)); // NOI18N
        rpmodificar.setText("Modificar");
        rpmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpmodificarActionPerformed(evt);
            }
        });
        getContentPane().add(rpmodificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, 100, -1));

        rpcancelar.setBackground(new java.awt.Color(0, 102, 153));
        rpcancelar.setFont(new java.awt.Font("Segoe UI Semilight", 1, 14)); // NOI18N
        rpcancelar.setText("Cancelar");
        rpcancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rpcancelarMouseClicked(evt);
            }
        });
        getContentPane().add(rpcancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 440, 100, -1));

        rpmantenimiento.setBackground(new java.awt.Color(0, 102, 102));
        rpmantenimiento.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        rpmantenimiento.setForeground(new java.awt.Color(255, 255, 255));
        rpmantenimiento.setText("Mantenimiento");
        rpmantenimiento.setBorder(new javax.swing.border.MatteBorder(null));
        getContentPane().add(rpmantenimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 140, 40));

        rpbusqueda.setBackground(new java.awt.Color(0, 102, 102));
        rpbusqueda.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        rpbusqueda.setForeground(new java.awt.Color(255, 255, 255));
        rpbusqueda.setText("Búsqueda");
        rpbusqueda.setBorder(new javax.swing.border.MatteBorder(null));
        rpbusqueda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rpbusquedaMouseClicked(evt);
            }
        });
        rpbusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rpbusquedaActionPerformed(evt);
            }
        });
        getContentPane().add(rpbusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 150, 40));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Fecha de nacimiento", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14))); // NOI18N
        jPanel1.setName(""); // NOI18N

        jLabel2.setText("dia");
        jPanel1.add(jLabel2);

        rpdia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jPanel1.add(rpdia);

        jLabel3.setText("mes");
        jPanel1.add(jLabel3);

        rpmes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jPanel1.add(rpmes);

        jLabel4.setText("año");
        jPanel1.add(jLabel4);

        rpaño.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017" }));
        jPanel1.add(rpaño);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 120, 370, 60));
        jPanel1.getAccessibleContext().setAccessibleName("");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/REGISTRO DE PACIENTES REBORN v1.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void rpemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rpemailActionPerformed

    private void rpmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpmodificarActionPerformed
        desbloquear();
    }//GEN-LAST:event_rpmodificarActionPerformed

    private void rpbusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpbusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rpbusquedaActionPerformed

    private void rpbusquedaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rpbusquedaMouseClicked
       registrodepaciente2 n=new  registrodepaciente2();
       n.setVisible(true);
       dispose();
    }//GEN-LAST:event_rpbusquedaMouseClicked

    private void rpcancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rpcancelarMouseClicked
       panel n=new  panel();
       n.setVisible(true);
       dispose();
    }//GEN-LAST:event_rpcancelarMouseClicked

    private void rpguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpguardarActionPerformed
       if(band==1)
       {
           try {
           PreparedStatement pps = cn.prepareStatement("INSERT INTO paciente(nombres,direccion,email,dni,peso,talla,celular,estado_civil,telefono,fech_nac) VALUES(?,?,?,?,?,?,?,?,?,?)");
           pps.setString(1, rpnombre.getText());
           pps.setString(4, rpdireccion.getText());
           pps.setString(5, rpemail.getText());
           pps.setString(6, rpdni.getText());
           pps.setString(7, rppeso.getText());
           pps.setString(8, rptalla.getText());
           pps.setString(9, rpcel.getText());
           pps.setString(10, rpestcivil.getSelectedItem().toString());
           pps.setString(11, rptel.getText());
           String fecha = rpaño.getSelectedItem().toString()+'-'+rpmes.getSelectedItem().toString()+'-'+rpdia.getSelectedItem().toString();
           pps.setString(12, fecha);
          
           
       pps.executeUpdate();
       JOptionPane.showMessageDialog(null, "Datos guardados");
       } catch (SQLException ex) {
           Logger.getLogger(registrodepaciente1.class.getName()).log(Level.SEVERE, null, ex);
       }
       }
    else
           {
                          try {
           PreparedStatement pps = cn.prepareStatement("INSERT INTO paciente(nombres,direccion,email,dni,peso,talla,celular,estado_civil,telefono,fech_nac) VALUES(?,?,?,?,?,?,?,?,?,?)");
           pps.setString(1, rpnombre.getText());
           pps.setString(4, rpdireccion.getText());
           pps.setString(5, rpemail.getText());
           pps.setString(6, rpdni.getText());
           pps.setString(7, rppeso.getText());
           pps.setString(8, rptalla.getText());
           pps.setString(9, rpcel.getText());
           pps.setString(10, rpestcivil.getSelectedItem().toString());
           pps.setString(11, rptel.getText());
           String fecha = rpaño.getSelectedItem().toString()+'-'+rpmes.getSelectedItem().toString()+'-'+rpdia.getSelectedItem().toString();
           pps.setString(12, fecha);
          
           
       pps.executeUpdate();
       JOptionPane.showMessageDialog(null, "Datos guardados");
       } catch (SQLException ex) {
           Logger.getLogger(registrodepaciente1.class.getName()).log(Level.SEVERE, null, ex);
       }
           }
           

          bloquear();
       limpiar();
    }//GEN-LAST:event_rpguardarActionPerformed

    private void rpnombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rpnombreKeyTyped
    char c = evt.getKeyChar();
    if((c<'a' || c>'z') && (c<'A' || c>'Z') && (c<' ' || c>' ')) evt.consume();
 
    }//GEN-LAST:event_rpnombreKeyTyped

    private void rpdniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rpdniKeyTyped
      char c = evt.getKeyChar();
    if(c<'0' || c>'9') evt.consume();
 
    }//GEN-LAST:event_rpdniKeyTyped

    private void rpcelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rpcelKeyTyped
     char c = evt.getKeyChar();
    if(c<'0' || c>'9') evt.consume();
 
    }//GEN-LAST:event_rpcelKeyTyped

    private void rppesoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rppesoKeyTyped
        char c = evt.getKeyChar();
    if(c<'0' || c>'9' || c=='.'|| c==',') evt.consume();
 
    }//GEN-LAST:event_rppesoKeyTyped

    private void rptelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_rptelKeyTyped
        char c = evt.getKeyChar();
        if(c<'0' || c>'9') evt.consume();
    }//GEN-LAST:event_rptelKeyTyped

    private void rpnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rpnuevoActionPerformed
        
    desbloquear();  
        
        
    }//GEN-LAST:event_rpnuevoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(registrodepaciente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registrodepaciente1().setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JComboBox<String> rpaño;
    private javax.swing.JButton rpbusqueda;
    private javax.swing.JButton rpcancelar;
    private javax.swing.JTextField rpcel;
    private javax.swing.JComboBox<String> rpdia;
    private javax.swing.JTextField rpdireccion;
    public static javax.swing.JTextField rpdni;
    private javax.swing.JTextField rpemail;
    private javax.swing.JComboBox<String> rpestcivil;
    private javax.swing.JButton rpguardar;
    private javax.swing.JButton rpmantenimiento;
    private javax.swing.JComboBox<String> rpmes;
    private javax.swing.JButton rpmodificar;
    public static javax.swing.JTextField rpnombre;
    private javax.swing.JButton rpnuevo;
    private javax.swing.JTextField rppeso;
    private javax.swing.JTextField rptalla;
    private javax.swing.JTextField rptel;
    // End of variables declaration//GEN-END:variables
}
